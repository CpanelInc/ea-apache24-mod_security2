Please access the ModSecurity Github space to access the below documentation.

    * ModSecurity 2 Data Formats
    * ModSecurity Frequently Asked Questions (FAQ)
    * ModSecurity Migration Matrix
    * ModSecurity Rules Language Porting Specification
    * ModSecurity Wiki
    * Reference Manual
    * RoadMap

https://github.com/owasp-modsecurity/ModSecurity/wiki/
